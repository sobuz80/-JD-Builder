DROP TABLE IF EXISTS `#__jdbuilder_pages`;
DROP TABLE IF EXISTS `#__jdbuilder_configs`;