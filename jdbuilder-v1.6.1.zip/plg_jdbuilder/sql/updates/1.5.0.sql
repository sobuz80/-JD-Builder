ALTER TABLE `#__jdbuilder_layouts` DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `#__jdbuilder_favourites` DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci;
ALTER TABLE `#__jdbuilder_templates` DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_unicode_ci;