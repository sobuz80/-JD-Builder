DROP TABLE IF EXISTS `#__jdbuilder_layouts`;
DROP TABLE IF EXISTS `#__jdbuilder_favourites`;
DROP TABLE IF EXISTS `#__jdbuilder_templates`;