## JD Builder
### The magical Joomla page builder

[![Watch Intro Video here](https://www.joomdev.com/images/githubassets/builder-play.jpg)](https://www.youtube.com/watch?v=5xwaA-fphvc)


### [Read More](https://www.joomdev.com/jd-builder)

### [Help Translate JD Builder](https://github.com/joomdev/JD-Builder/wiki/Translations)
### [Documentation](https://docs.joomdev.com/category/jd-builder/)
### [Support](https://www.joomdev.com/forum/jd-builder)
